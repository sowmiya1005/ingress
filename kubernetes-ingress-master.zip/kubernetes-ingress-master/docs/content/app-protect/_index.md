---
title: Using with NGINX App Protect
description: Learn how to use NGINX Ingress Controller for Kubernetes with NGINX App Protect.
weight: 1600
menu:
  docs:
    parent: NGINX Ingress Controller
---
